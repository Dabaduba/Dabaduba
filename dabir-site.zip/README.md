# Dabir Uddin personal site

A fake Hyprland desktop in plain HTML, CSS and JavaScript. No build step.
Open `index.html` in a browser, or push the folder to GitHub Pages.

## Files and load order
`index.html` loads `css/style.css`, then the scripts below in this order
(order matters, they share globals):

| file | what it does |
|------|--------------|
| js/core.js | helpers, state (cfg, ws, wins), save(), toast() |
| js/themes.js | color themes, theme(), setCfg() |
| js/apps.js | the content of every window. Edit your text here |
| js/terminal.js | terminal commands (add a `case` to the switch) |
| js/wm.js | open/close/focus windows, workspaces, tiling layout() |
| js/launcher.js | the alt+d launcher |
| js/keys.js | alt+... keybinds |
| js/widgets.js | cava bars, htop numbers, clock |
| js/main.js | boot screen and startup sequence |

## Debugging tips
- Open DevTools (F12). Errors show the file and line, e.g. `wm.js:40`.
- Every function and variable is global, so you can type `wins`, `cfg` or `go(3)` in the console.
- Window not where you expect: look at `layout()` in wm.js.
- Wrong text: apps.js. Wrong color: the variables at the top of style.css.
- Boot too slow: the delay is the number at the end of the setInterval in main.js.
